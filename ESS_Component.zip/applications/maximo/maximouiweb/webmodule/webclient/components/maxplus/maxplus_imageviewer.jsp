<%@ page import="psdi.webclient.system.session.WebClientSession,psdi.util.*,java.util.*,psdi.security.UserInfo,psdi.server.MXServer"%>
<%@ page import="java.io.IOException"%>
<%@ page import="psdi.mbo.MboRemote"%>
<%@ page import="psdi.mbo.MboSetRemote"%>
<%@ page import="java.io.File"%>
<%@ page import="java.io.FileInputStream"%>
<%@ page import="java.io.ByteArrayOutputStream"%>
<%@ page import="java.util.Base64"%>
<%@ page import="java.util.Locale"%>
<%@ include file="../../common/componentheader.jsp" %>
<%
MboRemote currentMbo = null;
String label = component.getProperty("label");
String foldername = component.getProperty("foldername");
try {
    currentMbo = control.getPage().getDataBean().getMbo();
} catch (Exception e) {
    e.printStackTrace();
}
String ownerId = "";
String ownerTable = "";
String userName = "";
if (currentMbo != null) {
    try {
        ownerTable = currentMbo.getThisMboSet().getName();
        ownerId = String.valueOf(currentMbo.getLong(currentMbo.getUniqueIDName()));
        userName = currentMbo.getUserInfo().getUserName();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
String saveJspUrl = request.getContextPath() + "/webclient/components/maxplus/imageSave.jsp";
String imageBase64 = null;
String imageMimeType = null;
String imageFileName = null;
String filePath = null;
FileInputStream fis = null;
ByteArrayOutputStream baos = null;
File imageFile = null;
String lowerFileName = null;
String fileName = null;
try {
    if (currentMbo != null) {
        MboSetRemote doclinks = currentMbo.getMboSet("DOCLINKS");
        if (doclinks != null) {
            long latestTimestamp = -1L;
            for (int i = 0; i < doclinks.count(); i++) {
                MboRemote doclink = doclinks.getMbo(i);
                if (doclink == null) {
                    continue;
                }
                filePath = doclink.getString("URLNAME");
                String documentDesc = doclink.getString("DESCRIPTION");
                if (documentDesc == null || !documentDesc.toLowerCase(Locale.ENGLISH).startsWith(label + "_")) {
                    continue;
                }
                if (filePath == null || filePath.trim().length() == 0) {
                    filePath = doclink.getString("NEWURLNAME");
                }
                if (filePath == null || filePath.trim().length() == 0) {
                    continue;
                }
                filePath = filePath.trim();
                String normalizedPath = filePath.replace('\\', '/');
                int lastSlash = normalizedPath.lastIndexOf('/');
                if (lastSlash >= 0) {
                    fileName = normalizedPath.substring(lastSlash + 1);
                } else {
                    fileName = normalizedPath;
                }
                lowerFileName = fileName.toLowerCase(Locale.ENGLISH);
                if (!(lowerFileName.endsWith(".jpg") || lowerFileName.endsWith(".jpeg") || lowerFileName.endsWith(".png") || lowerFileName.endsWith(".gif") || lowerFileName.endsWith(".webp"))) {
                    continue;
                }
                int firstUnderscore = fileName.indexOf("_");
                int secondUnderscore = fileName.indexOf("_", firstUnderscore + 1);
                if (firstUnderscore == -1 || secondUnderscore <= firstUnderscore) {
                    continue;
                }
                String timestampString = fileName.substring(firstUnderscore + 1, secondUnderscore);
                long timestamp;
                try {
                    timestamp = Long.parseLong(timestampString);
                } catch (NumberFormatException e) {
                    continue;
                }
                /* Keep only the latest image. */
                if (timestamp <= latestTimestamp) {
                    continue;
                }
                imageFile = new File(filePath);
                if (!imageFile.exists() || !imageFile.isFile() || !imageFile.canRead()) {
                    continue;
                }
                latestTimestamp = timestamp;
                if (lowerFileName.endsWith(".jpg") || lowerFileName.endsWith(".jpeg")) {
                    imageMimeType = "image/jpeg";
                } else if (lowerFileName.endsWith(".png")) {
                    imageMimeType = "image/png";
                } else if (lowerFileName.endsWith(".gif")) {
                    imageMimeType = "image/gif";
                } else if (lowerFileName.endsWith(".webp")) {
                    imageMimeType = "image/webp";
                }
                try {
                    fis = new FileInputStream(imageFile);
                    baos = new ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        baos.write(buffer, 0, bytesRead);
                    }
                    imageBase64 = Base64.getEncoder().encodeToString(baos.toByteArray());
                    imageFileName = fileName;
                } finally {
                    if (fis != null) {
                        try {
                            fis.close();
                        } catch (Exception e) {
                            // Ignore
                        }
                    }
                    if (baos != null) {
                        try {
                            baos.close();
                        } catch (Exception e) {
                            // Ignore
                        }
                    }
                }
            }
        }
    }
} catch (Exception e) {
    e.printStackTrace();
    imageBase64 = null;
}
%>
<style>
.before-image-wrapper {
    width: 252px;
    font-family: Arial, sans-serif;
}
.before-image-container {
    width: 252px;
    height: 180px;
    border: 1px solid #d5d5d5;
    border-radius: 6px;
    background: #f7f7f7;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    box-sizing: border-box;
    margin: 5px 0;
}
.before-image-container img {
    max-width: 100%;
    max-height: 100%;
    width: auto;
    height: auto;
    object-fit: contain;
    display: block;
    cursor: pointer;
}
.before-image-empty {
    color: #777;
    font-size: 13px;
    text-align: center;
    padding: 20px;
}
.before-image-title {
    font-size: 12px;
    color: #555;
    margin-top: 4px;
    max-width: 252px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.before-upload-controls {
    margin-top: 8px;
}
.before-upload-file {
    position: absolute;
    width: 1px;
    height: 1px;
    opacity: 0;
    overflow: hidden;
}
.before-upload-buttons {
    margin-top: 8px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.before-upload-icon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    padding: 0;
    border: 1px solid #0072c3;
    background: #0072c3;
    color: white;
    border-radius: 4px;
    cursor: pointer;
    box-sizing: border-box;
}
.before-upload-icon-btn:hover {
    background: #005fa3;
}
.before-upload-icon-btn svg {
    width: 20px;
    height: 20px;
    fill: currentColor;
}
.before-upload-save {
    border-color: #1a7f37;
    background: #1a7f37;
}
.before-upload-save:hover {
    background: #156c2e;
}
.before-upload-save:disabled {
    background: #aaa;
    border-color: #aaa;
    cursor: not-allowed;
}
.before-upload-status {
    margin-top: 8px;
    font-size: 12px;
    min-height: 18px;
}
.before-upload-filename {
    display: none;
}
.before-image-label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 11px;
    font-weight: 700;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.6px;
    margin-bottom: 6px;
    padding-bottom: 6px;
    border-bottom: 1px solid #e5e7eb;
}
.before-image-label::before {
    content: "";
    width: 3px;
    height: 12px;
    background: #0072c3;
    border-radius: 1px;
    flex-shrink: 0;
}
/* Image dialog */
.before-image-dialog {
    border: none;
    padding: 0;
    margin: auto;
    background: transparent;
    max-width: 95vw;
    max-height: 95vh;
    overflow: visible;
}
/* Background behind dialog */
.before-image-dialog::backdrop {
    background: rgba(0, 0, 0, 0.65);
}
/* Dialog content */
.before-image-dialog-content {
    position: relative;
    background: #ffffff;
    border-radius: 6px;
    padding: 10px;
    box-sizing: border-box;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.45);
}
/* Original image size: width/height auto keep natural dimensions; max-width/max-height cap the viewport size. */
.before-image-dialog-content img {
    display: block;
    width: auto;
    height: auto;
    max-width: 90vw;
    max-height: 85vh;
    object-fit: contain;
}
/* Close button */
.before-image-dialog-close {
    position: absolute;
    top: -14px;
    right: -14px;
    width: 32px;
    height: 32px;
    padding: 0;
    border: none;
    border-radius: 50%;
    background: #333;
    cursor: pointer;
    z-index: 10;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.35);
}
/* CSS-only X. No special character / Unicode required. */
.before-image-dialog-close::before,
.before-image-dialog-close::after {
    content: "";
    position: absolute;
    width: 15px;
    height: 2px;
    background: #ffffff;
    top: 15px;
    left: 9px;
}
.before-image-dialog-close::before {
    transform: rotate(45deg);
}
.before-image-dialog-close::after {
    transform: rotate(-45deg);
}
.before-image-dialog-close:hover {
    background: #111;
}
</style>
<div id="<%=id%>" class="before-image-wrapper">
    <div class="before-image-label"><%=label%></div>
<%
if (imageBase64 != null && imageMimeType != null) {
%>
    <div class="before-image-container">
        <img id="<%=id%>_preview" src="data:<%=imageMimeType%>;base64,<%=imageBase64%>" alt="<%=label%> Attachment" title="Click to enlarge" />
    </div>
    <!-- Image Dialog: reuses the same original Base64 image, no resizing applied. -->
    <dialog id="<%=id%>_imageDialog" class="before-image-dialog">
        <div class="before-image-dialog-content">
            <button type="button" id="<%=id%>_closeDialog" class="before-image-dialog-close" title="Close" aria-label="Close"></button>
            <img id="<%=id%>_dialogImage" src="data:<%=imageMimeType%>;base64,<%=imageBase64%>" alt="<%=label%> Attachment" />
        </div>
    </dialog>
<%
} else {
%>
    <div class="before-image-container">
        <div id="<%=id%>_empty" class="before-image-empty">No <%=label%> image attachment found</div>
        <img id="<%=id%>_preview" alt="<%=label%> Image Preview" style="display:none;" />
    </div>
<%
}
%>
    <div class="before-upload-controls">
        <div class="before-upload-buttons">
            <label for="<%=id%>_file" class="before-upload-icon-btn" title="Browse" aria-label="Browse">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2z"/>
                </svg>
            </label>
            <input type="file" id="<%=id%>_file" class="before-upload-file" accept="image/jpeg,image/png,image/gif,image/webp" />
            <button type="button" id="<%=id%>_save" class="before-upload-icon-btn before-upload-save" title="Save Attachment" aria-label="Save Attachment" disabled>
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M17 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H6V5h9v4z"/>
                </svg>
            </button>
        </div>
        <div id="<%=id%>_status" class="before-upload-status"></div>
    </div>
</div>
<script>
(function() {
    var componentId = "<%=id%>";
    var fileInput = document.getElementById(componentId + "_file");
    var preview = document.getElementById(componentId + "_preview");
    var emptyMessage = document.getElementById(componentId + "_empty");
    var saveButton = document.getElementById(componentId + "_save");
    var status = document.getElementById(componentId + "_status");
    /* Image dialog elements. */
    var imageDialog = document.getElementById(componentId + "_imageDialog");
    var closeDialog = document.getElementById(componentId + "_closeDialog");
    /* Upload state. */
    var selectedFile = null;
    var selectedBase64 = null;
    var MAX_FILE_SIZE = 10 * 1024 * 1024;
    var ALLOWED_TYPES = ["image/jpeg", "image/png", "image/gif", "image/webp"];

    function setStatus(message, isError) {
        status.innerHTML = "";
        var text = document.createTextNode(message);
        status.appendChild(text);
        status.style.color = isError ? "#c00" : "#1a7f37";
    }

    function readFileAsBase64(file) {
        return new Promise(function(resolve, reject) {
            var reader = new FileReader();
            reader.onload = function(event) {
                var result = event.target.result;
                var commaIndex = result.indexOf(",");
                if (commaIndex === -1) {
                    reject(new Error("Invalid image data."));
                    return;
                }
                var base64 = result.substring(commaIndex + 1);
                resolve({ dataUrl: result, base64: base64 });
            };
            reader.onerror = function() {
                reject(new Error("Unable to read the image."));
            };
            reader.readAsDataURL(file);
        });
    }

    /* Open existing image in dialog. */
    if (preview && imageDialog) {
        preview.addEventListener("click", function() {
            if (preview.src && preview.style.display !== "none") {
                imageDialog.showModal();
            }
        });
    }

    /* Close image dialog. */
    if (closeDialog && imageDialog) {
        closeDialog.addEventListener("click", function() {
            imageDialog.close();
        });
    }

    /* Close when clicking outside image. */
    if (imageDialog) {
        imageDialog.addEventListener("click", function(event) {
            if (event.target === imageDialog) {
                imageDialog.close();
            }
        });
    }

    /* Native dialog also closes on ESC automatically. */
    if (imageDialog) {
        imageDialog.addEventListener("cancel", function() {
            imageDialog.close();
        });
    }

    fileInput.addEventListener("change", function() {
        selectedFile = null;
        selectedBase64 = null;
        saveButton.disabled = true;
        setStatus("", false);
        if (!fileInput.files || fileInput.files.length === 0) {
            return;
        }
        var file = fileInput.files[0];
        if (ALLOWED_TYPES.indexOf(file.type) === -1) {
            setStatus("Only JPG, PNG, GIF and WEBP images are allowed.", true);
            fileInput.value = "";
            return;
        }
        if (file.size > MAX_FILE_SIZE) {
            setStatus("Image size cannot exceed 10 MB.", true);
            fileInput.value = "";
            return;
        }
        setStatus("Reading image...", false);
        readFileAsBase64(file)
            .then(function(result) {
                selectedFile = file;
                selectedBase64 = result.base64;
                preview.src = result.dataUrl;
                preview.style.display = "block";
                if (emptyMessage) {
                    emptyMessage.style.display = "none";
                }
                saveButton.disabled = false;
                setStatus("Image ready to upload.", false);
            })
            .catch(function(error) {
                console.error(error);
                setStatus("Unable to read the selected image.", true);
            });
    });

    saveButton.addEventListener("click", function() {
        if (!selectedFile || !selectedBase64) {
            setStatus("Please select an image first.", true);
            return;
        }
        saveButton.disabled = true;
        setStatus("Saving attachment...", false);
        var saveJspUrl = "<%=saveJspUrl%>";
        var maximoOwnerTable = "<%=ownerTable%>";
        var maximoOwnerId = "<%=ownerId%>";
        var maximoUserName = "<%=userName%>";
        var maximoLabel = "<%=label%>";
        var maximoFolderName = "<%=foldername%>";

        console.log("===== SAVE REQUEST =====");
        console.log("Owner Table:", maximoOwnerTable);
        console.log("Owner ID:", maximoOwnerId);
        console.log("User:", maximoUserName);
        console.log("File:", selectedFile.name);
        console.log("MIME:", selectedFile.type);
        console.log("Size:", selectedFile.size);
        console.log("Base64 length:", selectedBase64.length);

        var body =
            "action=" + encodeURIComponent("upload") +
            "&ownerTable=" + encodeURIComponent(maximoOwnerTable) +
            "&ownerId=" + encodeURIComponent(maximoOwnerId) +
            "&userName=" + encodeURIComponent(maximoUserName) +
            "&fileName=" + encodeURIComponent(selectedFile.name) +
            "&mimeType=" + encodeURIComponent(selectedFile.type) +
            "&fileSize=" + encodeURIComponent(selectedFile.size) +
            "&maximoLabel=" + encodeURIComponent(maximoLabel) +
            "&maximoFolderName=" + encodeURIComponent(maximoFolderName) +
            "&imageBase64=" + encodeURIComponent(selectedBase64);

        fetch(saveJspUrl, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
            body: body
        })
        .then(function(response) {
            console.log("HTTP Status:", response.status);
            return response.text();
        })
        .then(function(text) {
            console.log("===== SERVER RESPONSE =====");
            console.log(text);
            var result;
            try {
                result = JSON.parse(text);
            } catch (e) {
                throw new Error("Invalid server response: " + text);
            }
            if (!result.success) {
                throw new Error(result.message || "Unable to save attachment.");
            }
            setStatus(result.message || "Attachment saved successfully.", false);
            fileInput.value = "";
            selectedFile = null;
            selectedBase64 = null;
            saveButton.disabled = true;
        })
        .catch(function(error) {
            console.error("SAVE ERROR:", error);
            setStatus(error.message || "Unable to save attachment.", true);
            saveButton.disabled = false;
        });
    });
})();
</script>
<%@ include file="../../common/componentfooter.jsp" %>
