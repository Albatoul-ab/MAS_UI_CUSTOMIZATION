<%@ page import="psdi.webclient.system.session.WebClientSession,psdi.util.*,java.util.*,psdi.security.UserInfo,psdi.server.MXServer"%>
<%@ page import="java.io.IOException"%>
<%@ page import="psdi.mbo.MboRemote"%>

<%@ include file="../../common/componentheader.jsp" %>

<%

    MboRemote mbo = control.getPage().getDataBean().getMbo();

    boolean isBreach = false;
    boolean isOnTime = false;

    Date actualFinish = null;
    Date targetFinish = null;

    if (mbo != null) {

        // Get Maximo Work Order date values
        if (!mbo.isNull("actfinish")) {
            actualFinish = mbo.getDate("actfinish");
        }

        if (!mbo.isNull("TARGCOMPDATE")) {
            targetFinish = mbo.getDate("TARGCOMPDATE");
        }

        /*
         * Maximo SLA/Breach Rule:
         *
         * ACTUALFINISH > TARGETFINISH  = BREACH
         * ACTUALFINISH <= TARGETFINISH = ON TIME
         */
        if (actualFinish != null && targetFinish != null) {

            if (actualFinish.after(targetFinish)) {
                isBreach = true;
            } else {
                isOnTime = true;
            }
        }
    }

%>

<style type="text/css">

    .maxplus-ontime-breach-container {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
    }

    .maxplus-ontime-breach-icon {
        object-fit: contain;
        display: block;
        margin: 0 auto;
    }

    .maxplus-ontime-breach-label {
        display: block;
        margin-top: 3px;
        font-size: 11px;
        font-weight: 600;
        line-height: 14px;
    }

    .maxplus-ontime-label {
        color: #198754;
    }

    .maxplus-breach-label {
        color: #dc3545;
    }

</style>

<div id="<%=id%>" class="maxplus-ontime-breach-container">

    <% if (isOnTime) { %>

        <!-- On Time -->
        <img
            class="maxplus-ontime-breach-icon"
            src="<%=request.getContextPath()%>/webclient/components/maxplus/images/on-time.png"
            alt="On Time"
            title="On Time"
        />

        <span class="maxplus-ontime-breach-label maxplus-ontime-label">
            On-Time
        </span>

    <% } else if (isBreach) { %>

        <!-- Delayed -->
        <img
            class="maxplus-ontime-breach-icon"
            src="<%=request.getContextPath()%>/webclient/components/maxplus/images/overdue.png"
            alt="Delayed"
            title="Delayed"
        />

        <span class="maxplus-ontime-breach-label maxplus-breach-label">
            Delayed !
        </span>

    <% } %>

</div>

<%@ include file="../../common/componentfooter.jsp" %>