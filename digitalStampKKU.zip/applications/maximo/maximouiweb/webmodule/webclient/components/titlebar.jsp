<%--
* Licensed Materials - Property of IBM
* 
* 5724-U18
* 
* (C) COPYRIGHT IBM CORP. 2006,2025 All Rights Reserved.
* 
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with
* IBM Corp.
--%><%@ include file="../common/componentheader.jsp" %><%
  boolean renderHeader = true;
  wcs.setHideTitlebar(true);
  if(request.getParameterMap().containsKey("hide-titlebar")){
    boolean hideTitlebar = Boolean.valueOf((String)request.getParameter("hide-titlebar"));
    wcs.setHideTitlebar(hideTitlebar);
  }
	if (wcs.getHideTitlebar() || designmode || wcs.getLightningPortalMode())
	{
		renderHeader = false;
	}	
	String apptitle = "";
	String docTitle = "";
	String height = component.getProperty("height");
	height = wcs.attachUOM(height);
	String userFullName = control.getWebClientSession().getUserInfo().getDisplayName();
	try
	{
		docTitle = control.getWebClientSession().getCurrentApp().getAppTitle();
		if(control.getWebClientSession().getCurrentApp().getId().equalsIgnoreCase("startcntr"))
		{
			if (BidiUtils.isBidiEnabled())     //bidi-hcg-SC
				userFullName = BidiUtils.enforceBidiDirection(userFullName, BidiUtils.getMboTextDirection("PERSON", "DISPLAYNAME", true)); //bidi-hcg-SC
			apptitle = control.getWebClientSession().getMessage("login","welcomeusername",new String[]{userFullName});
		}
	}
	catch(Exception e)
	{
		apptitle = "";
	}
//bidi-hcg-AS start
	if(BidiUtils.isBidiEnabled())
	{
		String[] bidiTagAttributes = BidiClientUtils.getTagAttributes(null,null,apptitle,false);
		if(bidiTagAttributes[2] != null && bidiTagAttributes[2].length() > 0)
		{
			apptitle = BidiUtils.enforceBidiDirection(apptitle,bidiTagAttributes[2]);
			docTitle = BidiUtils.enforceBidiDirection(docTitle,bidiTagAttributes[2]);
		}
	}
//bidi-hcg-AS end
	if(apptitle.equals(""))
		apptitle=docTitle;

	String appimage;
	try
	{
		appimage = control.getWebClientSession().getCurrentApp().getAppImage();
	}
	catch(Exception e)
	{
		appimage = "";
	}

	String informationImage = "information.gif";
	if(appimage == null || appimage.length() == 0)
	{
		if(app.getApp().toLowerCase().equals("startcntr"))
			appimage="appimg_startcntr.gif";
		else
			appimage="appimg_generic.gif";
	}
	String classname = "bgnb";
	String bgClass = "titlebarback";
	boolean applinking = app.inAppLinkMode();
	if(applinking)
	{
		classname = "alnb";
		bgClass+="_applink";
	}
	cssclass = classname +" "+ cssclass;

	boolean thePortalMode = control.getWebClientSession().getPortalMode();
	if (thePortalMode)
	{
		appimage = "blank.gif";
		informationImage = "blank.gif";
		cssclass = "bgnbp";
		if (!applinking)
			apptitle = "";
	}
	boolean useHomeButton = false;
	boolean useGotoButton = false;
	if(component.needsRender())
	{
		String homeButtonProperty = component.getProperty("homebutton");
		if(!homeButtonProperty.equals("false"))
		{
			String homeButtonSysSetting = "1";
			boolean isMobile = currentPage.getAppInstance().isMobile() || wcs.getMobile(); 
			if(!isMobile && homeButtonSysSetting.equals("1") || homeButtonProperty.equals("true"))
			{
				useHomeButton = true;	
			}
		}
		useGotoButton = useHomeButton;
        if(useGotoButton && wcs.showSystemNavBar(currentPage)) {
            useGotoButton = true;
        }

        if(control.getProperty("gotoinheader").equals("false")){
        	useGotoButton=false;
        }
        
        if (applinking) {
            height="16px";
            cssclass="stubmsg";
        }
        if(docTitle==""){
        	//Probably Birt report viewer
        	docTitle="Document";
        } 
        
  if(renderHeader){ %>
	<td width="100%" align="<%=defaultAlign%>" class="<%=bgClass%>">
		<!-- Digital Government Stamp -->
		<div id="digital-stamp-wrapper" style="position:fixed;top:0;left:0;width:100%;z-index:99999;">
		<style>
		#digital-stamp-wrapper *{box-sizing:border-box;}
		#digital-stamp-wrapper .digital-stamp-card{padding:8px 32px;background:#f3f4f6;width:100%;}
		#digital-stamp-wrapper .digital-stamp-header{display:flex;align-items:center;gap:10px;}
		#digital-stamp-wrapper .digital-stamp-header h6{margin:0;color:#161616;font-size:14px;font-weight:normal;}
		#digital-stamp-wrapper .btn-digital-stamp-card{cursor:pointer;display:flex;align-items:center;gap:4px;background:none;border:none;padding:0;}
		#digital-stamp-wrapper .btn-digital-stamp-card span{color:#1b8354;font-size:14px;}
		#digital-stamp-wrapper .btn-digital-stamp-card svg{transition:transform 0.3s;}
		#digital-stamp-wrapper .digital-stamp-header.open .btn-digital-stamp-card svg{transform:rotate(180deg);}
		#digital-stamp-wrapper .digital-stamp-body{padding:40px 32px 32px;display:none;background:#f3f4f6;}
		#digital-stamp-wrapper .digital-stamp-container{margin-bottom:32px;display:flex;gap:32px;flex-wrap:wrap;}
		#digital-stamp-wrapper .box{display:flex;align-items:flex-start;gap:18px;}
		#digital-stamp-wrapper .img-border-rounded{padding:14px 16px;display:flex;align-items:center;justify-content:center;border:1px solid #067647;border-radius:50%;flex-shrink:0;}
		#digital-stamp-wrapper .box h6{margin:0 0 12px;color:#161616;font-size:18px;}
		#digital-stamp-wrapper .box .green-text{color:#1b8354;}
		#digital-stamp-wrapper .box p{margin:0;color:#384250;font-size:16px;}
		#digital-stamp-wrapper .stamp-link-box{padding:8px 28px;display:flex;align-items:center;gap:12px;border-radius:8px;background:#fff;}
		#digital-stamp-wrapper .stamp-link-box p{margin:0;color:#161616;font-size:16px;}
		#digital-stamp-wrapper .stamp-link-box a{color:#1b8354;font-size:16px;text-decoration:underline;}
		@media(max-width:768px){
		  #digital-stamp-wrapper .digital-stamp-card{padding:8px 16px;}
		  #digital-stamp-wrapper .digital-stamp-header{flex-wrap:wrap;}
		  #digital-stamp-wrapper .btn-digital-stamp-card{flex:100%;margin-left:33px;}
		  #digital-stamp-wrapper .digital-stamp-container{flex-direction:column;}
		  #digital-stamp-wrapper .digital-stamp-body{padding:24px 16px;}
		}
		</style>
		<div class="digital-stamp-card">
		  <div class="digital-stamp-header" id="dsHeader">
		    <svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
		      <rect width="20" height="14" fill="#006923"/>
		      <path fill-rule="evenodd" clip-rule="evenodd" d="M8.13775 3C8.12247 3 8.09956 3.00764 8.07029 3.02546C8.00155 3.07128 7.86664 3.21256 7.86154 3.37548C7.85773 3.4684 7.83991 3.4684 7.89973 3.52822C7.94301 3.58932 7.98883 3.58423 8.07538 3.53713C8.12629 3.49895 8.14284 3.47731 8.16066 3.41494C8.18102 3.31311 8.04992 3.46585 8.03338 3.34875C8.0041 3.24184 8.08811 3.19601 8.16702 3.09419C8.16957 3.04328 8.16957 3.00509 8.13775 3.00255V3Z" fill="white"/>
		    </svg>
		    <h6>Official government website of the Government of the Kingdom of Saudi Arabia</h6>
		    <button class="btn-digital-stamp-card" id="dsToggle" type="button">
		      <span>How to verify</span>
		      <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
		        <path d="M1.40248 0.703524C1.48374 0.811106 1.72634 1.13227 1.87083 1.31741C2.16021 1.68822 2.55561 2.18094 2.98215 2.67221C3.41085 3.16595 3.86119 3.64681 4.26126 4.00031C4.46187 4.17756 4.63809 4.31225 4.78351 4.39992C4.92028 4.48237 5.00107 4.49951 5.00107 4.49951C5.00107 4.49951 5.07949 4.48236 5.21625 4.39992C5.36167 4.31225 5.53789 4.17757 5.7385 4.00031C6.13858 3.64682 6.58892 3.16595 7.01761 2.6722C7.44415 2.18093 7.83955 1.6882 8.12894 1.31739C8.27342 1.13224 8.51569 0.811535 8.59695 0.703952C8.7607 0.481603 9.07404 0.433646 9.29639 0.597401C9.51874 0.761156 9.56623 1.07415 9.40248 1.2965L9.4013 1.29806C9.31618 1.41077 9.06477 1.74363 8.91729 1.93261C8.62137 2.3118 8.21441 2.81907 7.77271 3.32781C7.33316 3.83406 6.84938 4.35319 6.40064 4.74969C6.17684 4.94744 5.94998 5.12525 5.73253 5.25634C5.52882 5.37915 5.27089 5.5 4.99988 5.5C4.72887 5.5 4.47095 5.37914 4.26723 5.25633C4.04979 5.12525 3.82293 4.94744 3.59913 4.74969C3.15038 4.35319 2.6666 3.83406 2.22705 3.32782C1.78535 2.81909 1.3784 2.31182 1.08248 1.93264C0.934942 1.74359 0.683627 1.41086 0.598597 1.29828L0.59752 1.29686C0.433763 1.07451 0.481027 0.761191 0.703374 0.597435C0.925715 0.433684 1.23872 0.481194 1.40248 0.703524Z" fill="#1B8354"/>
		      </svg>
		    </button>
		  </div>
		  <div class="digital-stamp-body" id="dsBody">
		    <div class="digital-stamp-container">
		      <div class="box">
		        <div class="img-border-rounded">
		          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
		            <path d="M19.4675 4.59755C17.7411 2.80082 14.9292 2.80082 13.2028 4.59755L12.4893 5.34015C12.2023 5.63883 12.2118 6.11361 12.5105 6.4006C12.8092 6.68758 13.284 6.6781 13.5709 6.37942L14.2845 5.63682C15.4206 4.45439 17.2497 4.45439 18.3859 5.63682C19.5382 6.83611 19.5382 8.79249 18.3859 9.99178L15.1465 13.3632C14.9668 13.5502 14.7711 13.7065 14.565 13.8332C13.4569 14.5143 12.0056 14.3629 11.0451 13.3632C10.8888 13.2006 10.7539 13.0244 10.6402 12.8381C10.4243 12.4846 9.96276 12.373 9.60925 12.5889C9.25573 12.8047 9.14414 13.2663 9.36001 13.6198C9.52954 13.8975 9.73075 14.1603 9.96346 14.4025C11.418 15.9162 13.6477 16.1577 15.3504 15.1111C15.6651 14.9177 15.9603 14.6811 16.2281 14.4025L19.4675 11.0311C21.1777 9.25119 21.1776 6.37741 19.4675 4.59755Z" fill="#067647"/>
		            <path d="M14.0368 9.59754C12.3104 7.80082 9.49845 7.80082 7.77206 9.59754L4.53264 12.9689C2.82245 14.7488 2.82245 17.6226 4.53264 19.4025C6.25903 21.1992 9.07094 21.1992 10.7973 19.4025L11.5111 18.6596C11.7981 18.3609 11.7886 17.8861 11.4899 17.5991C11.1913 17.3122 10.7165 17.3216 10.4295 17.6203L9.71571 18.3632C8.57957 19.5456 6.7504 19.5456 5.61426 18.3632C4.46191 17.1639 4.46191 15.2075 5.61426 14.0082L8.85368 10.6368C9.98982 9.45439 11.819 9.45439 12.9551 10.6368C13.1113 10.7994 13.2462 10.9756 13.3599 11.1617C13.5758 11.5152 14.0374 11.6268 14.3909 11.4109C14.7444 11.195 14.856 10.7334 14.6401 10.3799C14.4706 10.1024 14.2694 9.83967 14.0368 9.59754Z" fill="#067647"/>
		          </svg>
		        </div>
		        <div>
		          <h6>Links to official Saudi websites end with <span class="green-text">sa</span></h6>
		          <p>All links to official websites of government agencies in the Kingdom of Saudi Arabia end with gov.sa.</p>
		        </div>
		      </div>
		      <div class="box">
		        <div class="img-border-rounded">
		          <svg width="18" height="22" viewBox="0 0 18 22" fill="none">
		            <path d="M5.5 14.5C5.5 13.9477 5.94772 13.5 6.5 13.5H6.50897C7.06125 13.5 7.50897 13.9477 7.50897 14.5C7.50897 15.0523 7.06125 15.5 6.50897 15.5H6.5C5.94772 15.5 5.5 15.0523 5.5 14.5Z" fill="#067647"/>
		            <path d="M10.491 14.5C10.491 13.9477 10.9387 13.5 11.491 13.5H11.5C12.0523 13.5 12.5 13.9477 12.5 14.5C12.5 15.0523 12.0523 15.5 11.5 15.5H11.491C10.9387 15.5 10.491 15.0523 10.491 14.5Z" fill="#067647"/>
		            <path fill-rule="evenodd" clip-rule="evenodd" d="M3.75 7.45909L3.75 5.5C3.75 2.6005 6.1005 0.25 9 0.25C11.8995 0.25 14.25 2.6005 14.25 5.5V7.45909C15.9408 7.86285 17.239 9.29844 17.4755 11.0552C17.6236 12.1556 17.75 13.3118 17.75 14.5C17.75 15.6882 17.6236 16.8444 17.4755 17.9448C17.2039 19.9618 15.5328 21.5555 13.4748 21.6501C12.0464 21.7158 10.5958 21.75 9 21.75C7.40416 21.75 5.95364 21.7158 4.52522 21.6501C2.46716 21.5555 0.796088 19.9618 0.524518 17.9448C0.376363 16.8444 0.25 15.6882 0.25 14.5C0.25 13.3118 0.376363 12.1556 0.524518 11.0552C0.761044 9.29844 2.05919 7.86285 3.75 7.45909ZM5.25 5.5C5.25 3.42893 6.92893 1.75 9 1.75C11.0711 1.75 12.75 3.42893 12.75 5.5V7.31937C11.5532 7.27365 10.3269 7.25 9 7.25C7.67315 7.25 6.44676 7.27365 5.25 7.31937L5.25 5.5ZM9 8.75C7.42645 8.75 5.9989 8.78372 4.5941 8.8483C3.2851 8.90848 2.18929 9.93188 2.0111 11.2553C1.86573 12.3351 1.75 13.4129 1.75 14.5C1.75 15.5871 1.86573 16.6649 2.0111 17.7447C2.18929 19.0681 3.2851 20.0915 4.5941 20.1517C5.9989 20.2163 7.42645 20.25 9 20.25C10.5736 20.25 12.0011 20.2163 13.4059 20.1517C14.7149 20.0915 15.8107 19.0681 15.9889 17.7447C16.1343 16.6649 16.25 15.5871 16.25 14.5C16.25 13.4129 16.1343 12.3351 15.9889 11.2553C15.8107 9.93188 14.7149 8.90848 13.4059 8.8483C12.0011 8.78372 10.5736 8.75 9 8.75Z" fill="#067647"/>
		          </svg>
		        </div>
		        <div>
		          <h6>Government websites use the <span class="green-text">HTTPS</span> protocol for encryption and security.</h6>
		          <p>Secure websites in the Kingdom of Saudi Arabia use the HTTPS protocol for encryption.</p>
		        </div>
		      </div>
		    </div>
		    <div class="stamp-link-box">
		      <svg width="21" height="31" viewBox="0 0 21 31" fill="none" xmlns="http://www.w3.org/2000/svg">
		        <g>
		          <path d="M11.3686 15.0182C11.213 15.1314 11.114 15.3152 11.114 15.5132V20.5334C11.114 20.8728 11.3827 21.1415 11.7221 21.1415C12.0615 21.1415 12.3302 20.8728 12.3302 20.5334V15.8243L17.6615 12.091C17.8454 12.1899 18.0433 12.2324 18.2696 12.2324C18.9908 12.2324 19.5848 11.6526 19.5848 10.9172C19.5848 10.196 19.005 9.60205 18.2696 9.60205C17.5484 9.60205 16.9544 10.1819 16.9544 10.9172C16.9544 10.9738 16.9544 11.0303 16.9686 11.0728L11.3686 15.0182Z" fill="url(#dsp0)"/>
		          <path d="M7.59282 13.6889V18.695C7.16857 18.9213 6.88574 19.3455 6.88574 19.8546C6.88574 20.5758 7.46554 21.1697 8.2009 21.1697C8.92211 21.1697 9.51605 20.5899 9.51605 19.8546C9.51605 19.3455 9.23322 18.9071 8.80898 18.695V14.0142L16.6999 8.49898C16.8555 8.38585 16.9545 8.20201 16.9545 8.00403V4.27068C16.9545 3.93129 16.6858 3.6626 16.3464 3.6626C16.007 3.6626 15.7383 3.93129 15.7383 4.27068V7.67878L7.84736 13.194C7.67766 13.2929 7.57867 13.4768 7.59282 13.6889Z" fill="url(#dsp1)"/>
		          <path d="M17.0393 15.3576L15.0312 16.7718C14.7484 16.9697 14.6918 17.3374 14.8898 17.6203C15.0029 17.79 15.2009 17.8748 15.3847 17.8748C15.512 17.8748 15.6251 17.8465 15.7383 17.7617L17.7464 16.3475C18.0292 16.1495 18.0858 15.7819 17.8878 15.499C17.7039 15.2303 17.3221 15.1596 17.0393 15.3576Z" fill="url(#dsp2)"/>
		          <path d="M20.8858 18.9071C20.6878 18.6243 20.306 18.5536 20.0231 18.7516L10.5059 25.4122L0.988723 18.7516C0.705894 18.5536 0.324069 18.6243 0.126088 18.9071C-0.0718928 19.19 -0.00118027 19.5718 0.281649 19.7698L9.43119 26.1759L6.75844 28.0567C6.5746 27.9577 6.36248 27.9153 6.15036 27.9153C5.41501 27.9153 4.82106 28.5092 4.82106 29.2446C4.82106 29.9799 5.41501 30.5738 6.15036 30.5738C6.88572 30.5738 7.47966 29.9799 7.47966 29.2446C7.47966 29.188 7.47966 29.1314 7.46552 29.0749L10.5201 26.9395L13.5746 29.0749C13.5746 29.1314 13.5605 29.188 13.5605 29.2446C13.5605 29.9799 14.1544 30.5738 14.8898 30.5738C15.6251 30.5738 16.2191 29.9799 16.2191 29.2446C16.2191 28.5092 15.6251 27.9153 14.8898 27.9153C14.6635 27.9153 14.4655 27.9718 14.2817 28.0567L11.609 26.1759L20.7585 19.7698C21.0131 19.5718 21.0838 19.19 20.8858 18.9071Z" fill="url(#dsp3)"/>
		          <path d="M3.97253 4.46872L5.98062 3.05457C6.26345 2.85659 6.32002 2.48891 6.12204 2.20608C6.00891 2.03639 5.81093 1.95154 5.62709 1.95154C5.49981 1.95154 5.38668 1.97982 5.27355 2.06467L3.26546 3.47882C2.98263 3.6768 2.92606 4.04447 3.12404 4.3273C3.30788 4.59599 3.6897 4.6667 3.97253 4.46872Z" fill="url(#dsp4)"/>
		          <path d="M12.2029 2.47476V5.82629L4.31192 11.3415C4.15636 11.4546 4.05737 11.6384 4.05737 11.8364V15.5698C4.05737 15.9092 4.32606 16.1778 4.66545 16.1778C5.00485 16.1778 5.27354 15.9092 5.27354 15.5698V12.1617L13.1645 6.64649C13.32 6.53336 13.419 6.34952 13.419 6.15154V2.47476C13.8433 2.24849 14.1261 1.82425 14.1261 1.31516C14.1261 0.593945 13.5463 0 12.8109 0C12.0897 0 11.4958 0.579803 11.4958 1.31516C11.5099 1.81011 11.7928 2.24849 12.2029 2.47476Z" fill="url(#dsp5)"/>
		          <path d="M2.72812 10.196C3.44933 10.196 4.04327 9.61623 4.04327 8.88087C4.04327 8.8243 4.04328 8.76774 4.02914 8.72531L9.62916 4.80812C9.78471 4.69499 9.8837 4.51115 9.8837 4.31317V0.622242C9.8837 0.282846 9.61502 0.0141602 9.27562 0.0141602C8.93623 0.0141602 8.66754 0.282846 8.66754 0.622242V4.00206L3.3362 7.72127C3.15236 7.62228 2.95438 7.57985 2.72812 7.57985C2.0069 7.57985 1.41296 8.15965 1.41296 8.89501C1.42711 9.61622 2.0069 10.196 2.72812 10.196Z" fill="url(#dsp6)"/>
		        </g>
		        <defs>
		          <linearGradient id="dsp0" x1="15.35" y1="3.96" x2="15.35" y2="27.77" gradientUnits="userSpaceOnUse"><stop stop-color="#00ABAF"/><stop offset="0.24" stop-color="#0093B4"/><stop offset="0.48" stop-color="#0080BA"/><stop offset="1" stop-color="#774896"/></linearGradient>
		          <linearGradient id="dsp1" x1="11.92" y1="3.96" x2="11.92" y2="27.77" gradientUnits="userSpaceOnUse"><stop stop-color="#00ABAF"/><stop offset="0.24" stop-color="#0093B4"/><stop offset="0.48" stop-color="#0080BA"/><stop offset="1" stop-color="#774896"/></linearGradient>
		          <linearGradient id="dsp2" x1="16.39" y1="3.96" x2="16.39" y2="27.77" gradientUnits="userSpaceOnUse"><stop stop-color="#00ABAF"/><stop offset="0.24" stop-color="#0093B4"/><stop offset="0.48" stop-color="#0080BA"/><stop offset="1" stop-color="#774896"/></linearGradient>
		          <linearGradient id="dsp3" x1="10.51" y1="3.96" x2="10.51" y2="27.77" gradientUnits="userSpaceOnUse"><stop stop-color="#29B2B2"/><stop offset="0.27" stop-color="#1091B3"/><stop offset="0.48" stop-color="#017EB5"/><stop offset="1" stop-color="#704B98"/></linearGradient>
		          <linearGradient id="dsp4" x1="4.62" y1="3.96" x2="4.62" y2="27.77" gradientUnits="userSpaceOnUse"><stop stop-color="#00ABAF"/><stop offset="0.24" stop-color="#0093B4"/><stop offset="0.48" stop-color="#0080BA"/><stop offset="1" stop-color="#774896"/></linearGradient>
		          <linearGradient id="dsp5" x1="9.09" y1="3.96" x2="9.09" y2="27.77" gradientUnits="userSpaceOnUse"><stop stop-color="#00ABAF"/><stop offset="0.24" stop-color="#0093B4"/><stop offset="0.48" stop-color="#0080BA"/><stop offset="1" stop-color="#774896"/></linearGradient>
		          <linearGradient id="dsp6" x1="5.66" y1="3.96" x2="5.66" y2="27.77" gradientUnits="userSpaceOnUse"><stop stop-color="#00ABAF"/><stop offset="0.24" stop-color="#0093B4"/><stop offset="0.48" stop-color="#0080BA"/><stop offset="1" stop-color="#774896"/></linearGradient>
		        </defs>
		      </svg>
		      <p>Registered with the Digital Government Authority under number :</p>
		      <a href="https://raqmi.dga.gov.sa/platforms/platforms/b5cc18f9-9208-456c-7b99-08dde011505d/platform-license">20250822259</a>
		    </div>
		  </div>
		</div>
		</div><!-- /digital-stamp-wrapper -->
		<script>
		(function(){
		  var btn=document.getElementById("dsToggle");
		  var header=document.getElementById("dsHeader");
		  var body=document.getElementById("dsBody");
		  if(btn&&header&&body){
		    btn.addEventListener("click",function(){
		      header.classList.toggle("open");
		      if(body.style.display==="none"||body.style.display===""){
		        body.style.display="block";
		        body.style.maxHeight=body.scrollHeight+"px";
		        body.style.overflow="hidden";
		        body.style.transition="max-height 0.3s ease";
		      } else {
		        body.style.maxHeight="0";
		        body.style.transition="max-height 0.3s ease";
		        setTimeout(function(){body.style.display="none";},300);
		      }
		    });
		  }
		  /* Push page body down so stamp doesn't overlap content */
		  function adjustBodyPadding(){
		    var wrapper=document.getElementById("digital-stamp-wrapper");
		    if(wrapper&&document.body){
		      document.body.style.paddingTop=wrapper.offsetHeight+"px";
		    }
		  }
		  if(document.readyState==="loading"){
		    document.addEventListener("DOMContentLoaded",adjustBodyPadding);
		  } else {
		    adjustBodyPadding();
		  }
		  window.addEventListener("resize",adjustBodyPadding);
		})();
		</script>
		<table width="100%" border="0" style="height: <%=height%>" class="<%=cssclass%>" role="presentation">
			<tr>
				<td style="vertical-align:top;white-space: nowrap;">
					<table cellspacing="0" cellpadding="0" role="presentation" style="height: 100%;">
						<tr>
							<%if(!accessibilityMode && !useHomeButton){%>
							<td width="35" class="applogo">
								<a id="appImageAnchor" href="javascript: sendEvent('focusfirst')"><img id="appimage" border="0" src="<%=IMAGE_PATH%><%=appimage%>" align="<%=defaultAlign%>" hspace="0" alt="<%=docTitle%>" /></a>
							</td>
							<%}%>
							<td style="white-space: nowrap">
							<%if(useHomeButton){ 
								String homeText = wcs.getMaxMessage("ui", "homelinktext").getMessage();
								String gotoText = wcs.getMaxMessage("ui", "gotoMenuText").getMessage();	%>
								<button type="button" id="<%=id%>_homeButton" onkeypress="if(hasKeyCode(event, 'KEYCODE_ENTER')){setClickPosition(this);this.click();}" onclick="setClickPosition(this);sendEvent('changeapp','<%=app.getId()%>','startcntr')" title="<%=homeText%>" alt="<%=homeText%>" aria-label="<%=homeText%>" onmouseout="this.className='homebutton';" onmouseover="this.className='homebutton homebuttonhover'" onblur="this.className='homebutton';" onfocus="this.className='homebutton homebuttonhover'" class="homebutton" <%if(accessibilityMode){%>style="background: transparent !important;"<%}%>>
                                    <img id="homebutton_image" src="<%= IMAGE_PATH%>ac_ban_home.png" style="display: inline<%if(accessibilityMode){%> !important<%}%>; margin: 0px -5px 0px -5px;" alt="<%=homeText%>"/>
                                </button>
                                <%if(useGotoButton){
                                %><button type="button" id="<%=id%>_gotoButton" onkeypress="if(hasKeyCode(event, 'KEYCODE_ENTER')){setClickPosition(this);this.click();}" onclick="setClickPosition(this);sendEvent('showmenu','<%=id%>_gotoButton','goto')" class="gotobutton" onmouseout="this.className='gotobutton';" onmouseover="this.className='gotobutton gotobuttonhover'" onblur="this.className='gotobutton';" onfocus="this.className='gotobutton gotobuttonhover'" title="<%=gotoText%>" alt="<%=gotoText%>" aria-label="<%=gotoText%>" <%if(accessibilityMode){%>style="background: transparent !important;"<%}%>>
                                    <img id="gotobutton_image" src="<%= IMAGE_PATH%>ac_ban_goto.png" style="display: inline<%if(accessibilityMode){%> !important<%}%>; margin: 0px -5px 0px -5px;" alt="<%=gotoText%>"/>
                                </button><%} 
                                if(!wcs.getMobile()){%><img aria-hidden="true" style="margin:0px;vertical-align: bottom" src="<%=IMAGE_PATH%>ac_ban_divider.png" alt=""/><%}%>
							<%}%>
							</td>
							<td style="vertical-align:<%if(useHomeButton){%>middle<%}else{%>top<%}%>;white-space: nowrap;">
								<span id="<%=id%>_appname" class="<%if(useHomeButton){%>homeButton<%}%>txtappname">&nbsp;
									<%=HTML.encodeTolerant(apptitle)%>
								</span>
							</td>
						</tr>
					</table>
				</td>
		<% }
      if(!ismobile)
			{	%>
				<td style="vertical-align:bottom;text-align:<%=defaultAlign%>">
					<table id="titlebar_error_table" class="umtable" border="0" cellspacing="0" cellpadding="0" style="text-align:<%=defaultAlign%>" role="presentation">
						<tr>
							<td><img id="titlebar_error_image" src="<%= IMAGE_PATH%><%=informationImage%>"  style="visibility:hidden" alt=""/></td>
							<td id="titlebar_error" role="alert" class="<%=textcss%> um" style="white-space: normal">&nbsp;</td>
						</tr>
					</table>
				</td>
		<%	}
        if(renderHeader){
       %>
			
				<td class="titlebarlinks" align="<%=reverseAlign%>" style="text-align:<%=reverseAlign%>">
					<table role="presentation" align="<%=reverseAlign%>" style="height: 100%" border="0" cellspacing="0" cellpadding="0">
						<tr><% if(!control.getProperty("usernameinheader").equals("false")){ %>
							<td>
								<span id="<%=id%>_username" class="homeButtontxtappname userfullname" style="display:none"><%=HTML.encodeTolerant(userFullName)%></span>
								<% if(psdi.server.MXServer.getMXServer().isAdminModeOn(true)){ 
									String adminMode = wcs.getMaxMessage("system", "EndAdminModeOn").getMessage(); 
									adminMode = adminMode.replaceAll("\\.", ""); %>
									<span id="adminMode" class="homeButtontxtappname userfullname adminMode"><%=adminMode%></span>
								<% } %>
							</td><%}%>
		<% }
	}
	if(!designmode) {
		component.renderChildrenControls(); //It has to be called, independent of needsrender
	}
	String companyName = "";
	if(accessibilityMode){
		companyName = wcs.getMaxMessage("fusion","CompanyName").getMessage();
	}
	if(component.needsRender() && renderHeader)
	{	%>
						</tr>
					</table>
				</td>
				<td class="titlelogo"><img src="ibm_logo_grey.png" alt="<%=companyName%>" style="display:inline"/></td>
			</tr>
			<tr>
				<td class="titlebarbottom" colspan="20"></td> 
			</tr>
        </table>
        <script>
        <%
	    	ControlInstance ssLink = control.getPage().getControlInstance("sslink");
	    	Iterator childIterator = control.getChildren().iterator();
	    	String ssLinkId = "";
	    	String gotoLinkId = "";
	    	while(childIterator.hasNext()){
	    		ControlInstance child = ((ControlInstance)childIterator.next());
	    		String childId = child.getId();
	    		String mxEvent = child.getProperty("mxevent");
	    		if(mxEvent.equals("startcenter")){
	    			ssLinkId = childId;
	    		}
	    		else if(mxEvent.equals("showmenu") && child.getProperty("eventvalue").equals("goto")){
	    			gotoLinkId = childId;
	    		}
	    	}
	       	if(useHomeButton && !"".equals(ssLinkId)){
				String ssHotKey = control.getPage().getControlInstance(ssLinkId).getProperty("accesskey");%>
				addLoadMethod("addHotKey('<%=ssHotKey%>', '<%=id%>_homeButton', 'click');");
        	<%}
        	if(useGotoButton && !"".equals(gotoLinkId)){
        		String gotoHotKey = control.getPage().getControlInstance(gotoLinkId).getProperty("accesskey"); %>
        		addLoadMethod("addHotKey('<%=gotoHotKey%>','<%=id%>_gotoButton', 'click');");
        	<%}%>
       	</script>
	</td>
<%	}
  String serverMessage = (String)app.get("servermessage");
	if(!WebClientRuntime.isNull(serverMessage))
	{
		String serverMessageType = (String)app.get("servermessagetype");
		if(WebClientRuntime.isNull(serverMessageType))
			serverMessageType="0"; 
		if(hiddenFrame)
		{	
			%><component id="<%=id%>_holder" role="alert" <%=compType%>><%="<![CDATA["%><%	
		}	%>
		<script>
	<%	if(!RequestHandler.getWebClientProperty("alertmessages","false").equals("true"))
		{	%>
			// IV37703 - Titlebar message not displaying for full timeout
			//addLoadMethod("showMessage(<%=serverMessageType%>, '<%=serverMessage%>', false);");
			addLoadMethod("showMessage(<%=serverMessageType%>, \"<%=serverMessage%>\", false);");  // RTC defect # 92784
	<% 	}
		else
		{	%>
			alert("<%=serverMessage%>");
	<%	}	%>
		</script>
	<%	if(hiddenFrame)
		{	
			%><%="]]>"%></component><%
		}
	}
	app.put("servermessage", "");
	app.put("servermessagetype", "");
%><%@ include file="../common/componentfooter.jsp" %>
