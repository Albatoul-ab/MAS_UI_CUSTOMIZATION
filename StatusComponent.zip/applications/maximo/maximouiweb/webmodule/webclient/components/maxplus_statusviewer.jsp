<%@ page import="psdi.webclient.system.session.WebClientSession,psdi.util.*,java.util.*,psdi.security.UserInfo,psdi.server.MXServer"%>
<%@ page import="java.io.IOException"%>
<%@ page import="psdi.mbo.MboRemote"%>

<%@ include file="../../common/componentheader.jsp" %>

<%

    /*
     * =========================================================
     * 1. GET CURRENT MBO
     * =========================================================
     */
    MboRemote mbo = control.getPage().getDataBean().getMbo();


    /*
     * =========================================================
     * 2. GET CURRENT DISPLAY STATUS
     * =========================================================
     *
     * This is the actual STATUS value displayed in Maximo.
     *
     * Example:
     *
     * STATUS = CANCELLED
     */
    String value = boundComponent.getString();

    if (value == null) {
        value = "";
    }

    value = value.trim();


    /*
     * =========================================================
     * 3. GET INTERNAL STATUS
     * =========================================================
     *
     * Convert the display STATUS to the internal Maximo status.
     *
     * Example:
     *
     * STATUS          = CANCELLED
     * INTERNAL STATUS = CLOSED
     */
    String internalStatus = "";

    if (mbo != null) {

        Translate translator =
            MXServer.getMXServer()
                   .getMaximoDD()
                   .getTranslator();

        internalStatus =
            translator.toInternalString(
                "SRSTATUS",
                mbo.getString("STATUS"),
                mbo
            );

        if (internalStatus == null) {
            internalStatus = "";
        }

        internalStatus = internalStatus.trim();
    }


    /*
     * =========================================================
     * 4. GET STATUS CONFIGURATION FROM XML
     * =========================================================
     *
     * Example:
     *
     * NEW:#0d6efd:NEW,
     * QUEUED:#6f42c1:QUEUED,
     * INPROG:#fd7e14:INPROG,
     * RESOLVED:#20c997:RESOLVED,
     * PENDING:#f0ad00:CLOSED,
     * CANCELLED:#dc3545:CLOSED,
     * CLOSED:#198754:CLOSED
     *
     *
     * FORMAT:
     *
     * DISPLAY_STATUS : COLOR : INTERNAL_STATUS
     */
    String statusValues =
        component.getProperty("statuslist");

    if (statusValues == null) {
        statusValues = "";
    }

    statusValues = statusValues.trim();


    /*
     * =========================================================
     * 5. MAP DISPLAY STATUS CONFIGURATION
     * =========================================================
     *
     * Key:
     *     DISPLAY STATUS
     *
     * Value:
     *     [COLOR, INTERNAL STATUS]
     */
    Map<String, String[]> statusConfig =
        new LinkedHashMap<String, String[]>();


    /*
     * =========================================================
     * 6. UNIQUE INTERNAL STATUS LIST
     * =========================================================
     *
     * LinkedHashSet is used to preserve XML order while
     * eliminating duplicate internal statuses.
     *
     * Example:
     *
     * NEW
     * QUEUED
     * INPROG
     * RESOLVED
     * CLOSED
     *
     * Even though PENDING, CANCELLED and CLOSED all map to
     * CLOSED, only ONE CLOSED bar will be created.
     */
    Set<String> internalStatuses =
        new LinkedHashSet<String>();


    /*
     * =========================================================
     * 7. PARSE XML STATUS CONFIGURATION
     * =========================================================
     */
    if (statusValues.length() > 0) {

        String[] entries =
            statusValues.split(",");


        for (int i = 0;
             i < entries.length;
             i++) {

            String entry =
                entries[i].trim();


            if (entry.length() == 0) {
                continue;
            }


            /*
             * Split:
             *
             * DISPLAY_STATUS : COLOR : INTERNAL_STATUS
             *
             * Limit = 3
             */
            String[] parts =
                entry.split(":", 3);


            /*
             * Ignore invalid configuration.
             */
            if (parts.length != 3) {
                continue;
            }


            String displayStatus =
                parts[0].trim();

            String color =
                parts[1].trim();

            String configuredInternalStatus =
                parts[2].trim();


            if (displayStatus.length() == 0 ||
                configuredInternalStatus.length() == 0) {

                continue;
            }


            /*
             * Store configuration.
             *
             * Example:
             *
             * CANCELLED
             *
             * [0] = #dc3545
             * [1] = CLOSED
             */
            statusConfig.put(
                displayStatus.toUpperCase(),
                new String[] {
                    color,
                    configuredInternalStatus
                }
            );


            /*
             * Add only the unique internal status.
             */
            internalStatuses.add(
                configuredInternalStatus.toUpperCase()
            );
        }
    }


    /*
     * =========================================================
     * 8. GET COLOR FOR CURRENT DISPLAY STATUS
     * =========================================================
     *
     * Example:
     *
     * value = CANCELLED
     *
     * Result:
     *
     * #dc3545
     */
    String activeColor = "#6c757d";

    String[] currentConfig =
        statusConfig.get(
            value.toUpperCase()
        );


    if (currentConfig != null &&
        currentConfig.length >= 1 &&
        currentConfig[0] != null &&
        currentConfig[0].trim().length() > 0) {

        activeColor =
            currentConfig[0].trim();
    }


    /*
     * =========================================================
     * 9. DETERMINE INTERNAL STATUS FROM XML CONFIGURATION
     * =========================================================
     *
     * We primarily use the Maximo translator result.
     *
     * Example:
     *
     * STATUS = CANCELLED
     *
     * Translator:
     *
     * CLOSED
     *
     */
    String translatedInternalStatus =
        internalStatus;


    /*
     * If translator didn't return a value, try the XML
     * configuration for the current display status.
     */
    if (translatedInternalStatus == null ||
        translatedInternalStatus.length() == 0) {

        if (currentConfig != null &&
            currentConfig.length >= 2) {

            translatedInternalStatus =
                currentConfig[1].trim();
        }
    }


    /*
     * =========================================================
     * 10. NORMALIZE INTERNAL STATUS
     * =========================================================
     */
    if (translatedInternalStatus == null) {
        translatedInternalStatus = "";
    }

    translatedInternalStatus =
        translatedInternalStatus.toUpperCase();

%>


<style type="text/css">

    /*
     * =========================================================
     * MAIN CONTAINER
     * =========================================================
     */
    .mx-status-container {
        width: 100%;
        padding: 4px 0;
        box-sizing: border-box;
    }


    /*
     * =========================================================
     * STATUS BAR CONTAINER
     * =========================================================
     */
    .mx-status-bars {
        display: flex;
        width: 100%;
        gap: 4px;
        align-items: flex-start;
    }


    /*
     * =========================================================
     * INDIVIDUAL STATUS ITEM
     * =========================================================
     */
    .mx-status-item {
        flex: 1;
        min-width: 0;
        text-align: center;
    }


    /*
     * =========================================================
     * INACTIVE BAR
     * =========================================================
     */
    .mx-status-bar {
        width: 100%;
        height: 10px;

        background-color: #d9d9d9;

        border: 1px solid #c6c6c6;

        border-radius: 3px;

        box-sizing: border-box;
    }


    /*
     * =========================================================
     * ACTIVE BAR
     *
     * Color is dynamically assigned from XML.
     * =========================================================
     */
    .mx-status-bar.active {
        border-color: transparent;
    }


    /*
     * =========================================================
     * STATUS LABEL
     * =========================================================
     */
    .mx-status-label {
        margin-top: 5px;

        font-size: 11px;

        color: #666;

        white-space: nowrap;

        overflow: hidden;

        text-overflow: ellipsis;
    }


    /*
     * =========================================================
     * ACTIVE LABEL
     * =========================================================
     */
    .mx-status-label.active {
        font-weight: bold;
    }

</style>


<div id="<%=id%>"
     class="mx-status-container">

    <div class="mx-status-bars">

        <%

            /*
             * =====================================================
             * 11. CREATE ONE BAR PER UNIQUE INTERNAL STATUS
             * =====================================================
             */
            int barIndex = 0;


            for (String configuredInternalStatus :
                    internalStatuses) {


                /*
                 * =================================================
                 * CHECK WHETHER THIS IS THE CURRENT INTERNAL STATUS
                 * =================================================
                 */
                boolean active =
                    configuredInternalStatus.equalsIgnoreCase(
                        translatedInternalStatus
                    );


                /*
                 * =================================================
                 * DEFAULT LABEL
                 * =================================================
                 *
                 * Inactive bars display the internal status.
                 */
                String displayLabel =
                    configuredInternalStatus;


                /*
                 * =================================================
                 * ACTIVE BAR LABEL
                 * =================================================
                 *
                 * Active bar displays the actual Maximo STATUS.
                 *
                 * Example:
                 *
                 * Internal = CLOSED
                 * STATUS   = CANCELLED
                 *
                 * Label = CANCELLED
                 */
                if (active &&
                    value.length() > 0) {

                    displayLabel =
                        value;
                }


                /*
                 * =================================================
                 * COLOR
                 * =================================================
                 *
                 * Only the active bar gets the color associated
                 * with the current DISPLAY STATUS.
                 */
                String barColor =
                    active
                        ? activeColor
                        : "#d9d9d9";

        %>


        <div class="mx-status-item">


            <!--
                 =================================================
                 STATUS BAR
                 =================================================
            -->

            <div id="<%=id%>_status_<%=barIndex%>"

                 class="mx-status-bar <%=active ? "active" : ""%>"

                 title="<%=displayLabel%>"

                 <% if (active) { %>

                 style="
                     background-color:<%=barColor%>;
                     border-color:<%=barColor%>;
                 "

                 <% } %>
            >
            </div>


            <!--
                 =================================================
                 STATUS LABEL
                 =================================================
            -->

            <div class="mx-status-label <%=active ? "active" : ""%>"

                 title="<%=displayLabel%>"

                 <% if (active) { %>

                 style="
                     color:<%=barColor%>;
                 "

                 <% } %>
            >

                <%=displayLabel%>

            </div>


        </div>


        <%

                barIndex++;
            }

        %>

    </div>

</div>


<%@ include file="../../common/componentfooter.jsp" %>