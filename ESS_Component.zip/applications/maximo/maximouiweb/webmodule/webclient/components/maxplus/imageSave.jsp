<%@ page contentType="application/json; charset=UTF-8" %>
<%@ page import="psdi.server.MXServer" %>
<%@ page import="psdi.security.UserInfo" %>
<%@ page import="psdi.mbo.MboRemote" %>
<%@ page import="psdi.mbo.MboSetRemote" %>
<%@ page import="java.io.File" %>
<%@ page import="java.io.FileOutputStream" %>
<%@ page import="java.util.Base64" %>
<%@ page import="java.util.Date" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.Locale" %>
<%@ page import="java.net.URLDecoder" %>
<%
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");

    File destinationFile = null;

    try {
        /* ================================================================
         * 1. GET PARAMETERS
         * ================================================================ */
        String action        = request.getParameter("action");
        String ownerTable     = request.getParameter("ownerTable");
        String ownerId        = request.getParameter("ownerId");
        String fileName       = request.getParameter("fileName");
        String mimeType       = request.getParameter("mimeType");
        String fileSizeString = request.getParameter("fileSize");
        String imageBase64    = request.getParameter("imageBase64");
        String userName       = request.getParameter("userName");
		String maximoLabel = request.getParameter("maximoLabel");
		String maximoFolderName = request.getParameter("maximoFolderName");

        /* ================================================================
         * 2. VALIDATE BASIC PARAMETERS
         * ================================================================ */
        if (!"upload".equalsIgnoreCase(action)) {
            throw new Exception("Invalid action.");
        }
        if (ownerTable == null || ownerTable.trim().length() == 0) {
            throw new Exception("Owner table was not provided.");
        }
        if (ownerId == null || ownerId.trim().length() == 0) {
            throw new Exception("Owner ID was not provided.");
        }
        if (fileName == null || fileName.trim().length() == 0) {
            throw new Exception("File name was not provided.");
        }
        if (mimeType == null || mimeType.trim().length() == 0) {
            throw new Exception("MIME type was not provided.");
        }
        if (imageBase64 == null || imageBase64.trim().length() == 0) {
            throw new Exception("Image data was not provided.");
        }
        if (userName == null || userName.trim().length() == 0) {
            throw new Exception("Maximo user name was not provided.");
        }
        userName = userName.trim();

        /* ================================================================
         * 3. SECURITY: ONLY ALLOW WORKORDER FOR THIS COMPONENT
         *
         * Do NOT allow the browser to decide arbitrary Maximo tables.
         * ================================================================ */
        if (!"WORKORDER".equalsIgnoreCase(ownerTable)) {
            throw new Exception("Invalid owner table.");
        }

        /* ================================================================
         * 4. ALLOWED MIME TYPES
         * ================================================================ */
        String extension;
        if ("image/jpeg".equalsIgnoreCase(mimeType)) {
            extension = ".jpg";
        } else if ("image/png".equalsIgnoreCase(mimeType)) {
            extension = ".png";
        } else if ("image/gif".equalsIgnoreCase(mimeType)) {
            extension = ".gif";
        } else if ("image/webp".equalsIgnoreCase(mimeType)) {
            extension = ".webp";
        } else {
            throw new Exception("Unsupported image type: " + mimeType);
        }

        /* ================================================================
         * 5. REMOVE DATA URL HEADER IF PRESENT
         *
         * Example: data:image/jpeg;base64,/9j/4AAQ...
         * ================================================================ */
        int commaIndex = imageBase64.indexOf(",");
        if (commaIndex >= 0) {
            imageBase64 = imageBase64.substring(commaIndex + 1);
        }

        /* ================================================================
         * 6. DECODE BASE64
         * ================================================================ */
        byte[] imageBytes;
        try {
            imageBytes = Base64.getDecoder().decode(imageBase64);
        } catch (IllegalArgumentException e) {
            throw new Exception("Invalid Base64 image data.");
        }

        /* ================================================================
         * 7. SIZE VALIDATION (max 10 MB)
         * ================================================================ */
        int maxFileSize = 10 * 1024 * 1024;
        if (imageBytes.length > maxFileSize) {
            throw new Exception("Image cannot exceed 10 MB.");
        }
        if (imageBytes.length == 0) {
            throw new Exception("Image is empty.");
        }

        /* ================================================================
         * 8. GET MAXIMO USER INFO
         * ================================================================ */
        MXServer mxServer = MXServer.getMXServer();
        UserInfo userInfo = mxServer.getUserInfo(userName);

        /*
         * Some Maximo configurations expose UserInfo differently.
         * Try the WebClient session if necessary.
         */
        if (userInfo == null) {
            Object sessionUser = session.getAttribute("USERINFO");
            if (sessionUser instanceof UserInfo) {
                userInfo = (UserInfo) sessionUser;
            }
        }
        if (userInfo == null) {
            throw new Exception("Maximo UserInfo was not found in the session.");
        }

        /* ================================================================
         * 9. GET WORKORDER
         * ================================================================ */
        MboSetRemote workorderSet = mxServer.getMboSet("WORKORDER", userInfo);
        if (workorderSet == null) {
            throw new Exception("Unable to create WORKORDER MboSet.");
        }

        try {
            /*
             * IMPORTANT: ownerId is intentionally kept as String.
             * We use the unique ID attribute rather than converting it to an integer.
             */
            String uniqueIdAttribute = "WORKORDERID";

            /* ------------------------------------------------------------
             * Find the requested record.
             * ------------------------------------------------------------ */
            String where = uniqueIdAttribute + " = " + ownerId;
            workorderSet.setWhere(where);
            workorderSet.reset();

            MboRemote workorder = workorderSet.getMbo(0);
            if (workorder == null) {
                throw new Exception("WORKORDER was not found.");
            }

            /* ------------------------------------------------------------
             * SECURITY CHECK
             *
             * Verify that the returned record actually has the requested ID.
             * ------------------------------------------------------------ */
            String actualId = workorder.getLong(uniqueIdAttribute) + "";
            if (!ownerId.equals(actualId)) {
                throw new Exception("WORKORDER validation failed.");
            }

            /* ================================================================
             * 10. GET DOCLINK PATH
             * ================================================================ */
            String beforeAfterFolder = maximoFolderName;
            MboSetRemote doctypesMboSet = mxServer.getMboSet("DOCTYPES", userInfo);
            doctypesMboSet.setWhere("DOCTYPE='" + beforeAfterFolder + "'");

            String doclinkPath = doctypesMboSet.getMbo(0).getString("DEFAULTFILEPATH");

            doclinkPath = (doclinkPath == null || doclinkPath.trim().length() == 0) ? mxServer.getProperty("mxe.doclink.doctypes.defpath") : doclinkPath;
            doclinkPath = (doclinkPath == null || doclinkPath.trim().length() == 0) ? mxServer.getProperty("mxe.doclink.doctypes.topLevelPaths") : doclinkPath;

            if (doclinkPath == null || doclinkPath.trim().length() == 0) {
                throw new Exception("mxe.doclink.doctypes.defpath is not configured.");
            }
            doclinkPath = doclinkPath.trim();

            /* ================================================================
             * 11. CREATE DIRECTORY
             * ================================================================ */
            File uploadDirectory = new File(doclinkPath);
            if (!uploadDirectory.exists()) {
                if (!uploadDirectory.mkdirs()) {
                    throw new Exception("Unable to create attachment directory: " + doclinkPath);
                }
            }
            if (!uploadDirectory.isDirectory()) {
                throw new Exception("Attachment path is not a directory.");
            }

            /* ================================================================
             * 12. GENERATE FILE NAME
             * ================================================================ */
			String wonum = workorder.getString("WONUM");
            String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
            String generatedFileName = maximoLabel + "_" + timestamp + "_" + wonum + extension;

            /* ================================================================
             * 13. CREATE PHYSICAL FILE
             * ================================================================ */
            destinationFile = new File(uploadDirectory, generatedFileName);

            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(destinationFile);
                fos.write(imageBytes);
                fos.flush();
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (Exception ignore) {
                    }
                }
            }

            /* ================================================================
             * 14. VERIFY FILE
             * ================================================================ */
            if (!destinationFile.exists() || !destinationFile.isFile() || destinationFile.length() == 0) {
                throw new Exception("Attachment file was not created correctly.");
            }

            /* ================================================================
             * 15. CREATE DOCLINK
             * ================================================================ */
            MboSetRemote doclinks = workorder.getMboSet("DOCLINKS");
            if (doclinks == null) {
                throw new Exception("DOCLINKS relationship was not found.");
            }
			MboRemote doclink = doclinks.add();
			doclink.setValue("URLTYPE", "FILE");            
            doclink.setValue("URLNAME", destinationFile.getAbsolutePath());
			doclink.setValue("NEWURLNAME", destinationFile.getAbsolutePath());                         
            doclink.setValue("DOCTYPE", beforeAfterFolder); 
			doclink.setValue("ADDINFO", true);	
            doclink.setValue("DESCRIPTION", generatedFileName);		

            /* ================================================================
             * 16. SAVE
             * ================================================================ */
            doclinks.save();
            

            /* ================================================================
             * 17. SUCCESS
             * ================================================================ */
            String safeFileName = generatedFileName
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");

            out.print(
                "{"
                + "\"success\":true,"
                + "\"message\":\"Attachment saved successfully.\","
                + "\"fileName\":\"" + safeFileName + "\","
                + "\"ownerTable\":\"WORKORDER\","
                + "\"ownerId\":\"" + ownerId + "\""
                + "}"
            );
        } finally {
            // Always close the MboSet.
            try {
                workorderSet.close();
            } catch (Exception ignore) {
            }
        }
    } catch (Exception e) {
        e.printStackTrace();

        /* ================================================================
         * DELETE PHYSICAL FILE IF DOCLINK FAILED
         * ================================================================ */
        if (destinationFile != null && destinationFile.exists()) {
            try {
                destinationFile.delete();
            } catch (Exception ignore) {
            }
        }

        String message = e.getMessage();
        if (message == null) {
            message = "Unknown error while saving attachment.";
        }
        message = message
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\r", "")
            .replace("\n", " ");

        out.print(
            "{"
            + "\"success\":false,"
            + "\"message\":\"" + message + "\""
            + "}"
        );
    }
%>
